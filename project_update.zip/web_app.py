from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash
from functools import wraps
from typing import List, Tuple
from datetime import datetime
import os
import time
import random
import threading
import queue
import json
import base64
try:
    import fcntl
except ImportError:
    fcntl = None

from utils import (
    load_config,
    save_config,
    add_page,
    delete_page,
    update_page,
    test_token,
    get_page_info,
    get_page_picture,
    get_posts,
    create_post,
    create_multi_image_post,
    delete_post,
    load_history,
    save_history,
)

app = Flask(__name__)
app.secret_key = "change-this-secret-key"  # สำหรับ flash message

# --- ระบบ Cache สำหรับสถานะ Page ---
# เก็บ { "page_id": { "token_status": "...", "token_expire": "...", "picture_url": "...", "timestamp": ... } }
PAGE_CACHE = {}
CACHE_TTL = 3600  # 1 ชั่วโมง

# --- ระบบ API Cooldown (ป้องกันเรียกถี่เกินไป) ---
API_LOCK = {}
LOCK_TIME = 300  # 5 นาที

def can_call_api(key):
    now = time.time()
    last = API_LOCK.get(key, 0)
    if now - last < LOCK_TIME:
        return False
    API_LOCK[key] = now
    return True

# --- Cache สำหรับหน้า /api/test ---
TEST_CACHE = {}
TEST_TTL = 600  # 10 นาที
LOCK_FILE = "/tmp/fb_worker.lock"
HISTORY_LOCK = threading.Lock()

# --- โฟลเดอร์เก็บไฟล์ชั่วคราวสำหรับ SEO Preview ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMP_DIR = os.path.join(BASE_DIR, "static", "temp_uploads")
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR, mode=0o755)

# --- ระบบ Authentication ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            flash("กรุณาเข้าสู่ระบบก่อนใช้งาน", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        config = load_config()
        auth = config.get("auth", {})
        
        if username == auth.get("username") and check_password_hash(auth.get("password_hash"), password):
            session["logged_in"] = True
            session["username"] = username
            flash("เข้าสู่ระบบสำเร็จ", "success")
            return redirect(url_for("index"))
        else:
            flash("Username หรือ Password ไม่ถูกต้อง", "danger")
            
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("ออกจากระบบเรียบร้อยแล้ว", "info")
    return redirect(url_for("login"))

# --- ระบบ Background Post Queue (Persistent File-based) ---
JOBS_FILE = "pending_jobs.json"
WORKER_STARTED = False

def add_to_queue(job):
    """บันทึกงานใหม่ลงไฟล์ เพื่อให้ข้ามกระบวนการและไม่หายหลังรีโหลด"""
    # แปลงรูปภาพ (bytes) เป็น Base64 เพื่อเก็บใน JSON
    if job.get("images"):
        for img in job["images"]:
            if isinstance(img.get("data"), bytes):
                img["data"] = base64.b64encode(img["data"]).decode("utf-8")
    
    # ใช้ fcntl สำหรับการล็อคไฟล์ข้าม Process (บน Linux)
    lock_path = JOBS_FILE + ".lock"
    try:
        with open(lock_path, "w") as lock_file:
            if fcntl:
                fcntl.flock(lock_file, fcntl.LOCK_EX)
            
            jobs = []
            if os.path.exists(JOBS_FILE):
                try:
                    with open(JOBS_FILE, "r", encoding="utf-8") as f:
                        jobs = json.load(f)
                except:
                    jobs = []
            
            jobs.append(job)
            with open(JOBS_FILE, "w", encoding="utf-8") as f:
                json.dump(jobs, f, ensure_ascii=False, indent=2)
            
            if fcntl:
                fcntl.flock(lock_file, fcntl.LOCK_UN)
    except Exception as e:
        print(f"❌ Queue error: {str(e)}")

def get_next_job():
    """ดึงงานถัดไปและลบออกจากไฟล์งานค้าง (Atomic + Cross-process Lock)"""
    lock_path = JOBS_FILE + ".lock"
    try:
        with open(lock_path, "w") as lock_file:
            if fcntl:
                fcntl.flock(lock_file, fcntl.LOCK_EX)
            
            if not os.path.exists(JOBS_FILE):
                if fcntl: fcntl.flock(lock_file, fcntl.LOCK_UN)
                return None
            
            try:
                with open(JOBS_FILE, "r", encoding="utf-8") as f:
                    jobs = json.load(f)
            except:
                if fcntl: fcntl.flock(lock_file, fcntl.LOCK_UN)
                return None
                
            if not jobs:
                if fcntl: fcntl.flock(lock_file, fcntl.LOCK_UN)
                return None
                
            job = jobs.pop(0)
            
            with open(JOBS_FILE, "w", encoding="utf-8") as f:
                json.dump(jobs, f, ensure_ascii=False, indent=2)
                
            if fcntl:
                fcntl.flock(lock_file, fcntl.LOCK_UN)

            # แปลงรูปภาพกลับจาก Base64 เป็น bytes
            if job.get("images"):
                for img in job["images"]:
                    if isinstance(img.get("data"), str):
                        img["data"] = base64.b64decode(img["data"])
                        
            return job
    except Exception as e:
        print(f"❌ Dequeue error: {str(e)}")
        return None

def worker_loop():
    """Background Worker สำหรับทยอยส่งโพสต์ (อ่านจากไฟล์)"""
    print("🚀 Persistent Background Worker Loop Started")
    while True:
        try:
            job = get_next_job()
            if not job:
                time.sleep(10) # ถ้าไม่มีงาน ให้รอ 10 วินาทีค่อยเช็คใหม่
                continue
            
            token = job.get("token")
            message = job.get("message")
            link = job.get("link")
            image_payloads = job.get("images", [])
            page_id = job.get("page_id")
            page_name = job.get("page_name")

            print(f"📦 Processing post for {page_name}...")
            
            try:
                if image_payloads:
                    res = create_multi_image_post(token, message, image_payloads)
                else:
                    res = create_post(token, message, link)
                
                if res.get("success") and res.get("post_id"):
                    with HISTORY_LOCK:
                        history = load_history()
                        history["items"].append({
                            "page_id": page_id,
                            "page_name": page_name,
                            "post_id": res.get("post_id"),
                            "post_url": res.get("post_url"),
                            "message_preview": (message or "โพสต์จาก Queue")[:150],
                            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "deleted": False,
                        })
                        save_history(history)
                    print(f"✅ Post success for {page_name}")
                else:
                    print(f"❌ Post failed for {page_name}: {res.get('error')}")
            except Exception as e:
                print(f"⚠️ Worker task error for {page_name}: {str(e)}")
            finally:
                pass
                # ไม่ต้องใช้ task_done() เพราะไม่ได้ใช้ queue.Queue แล้ว

            # ดีเลย์สุ่ม 15-25 วินาที
            time.sleep(random.randint(15, 25))
            
        except Exception as e:
            # ครอบ try/except วงนอกสุดเพื่อไม่ให้ thread ตาย
            print(f"🚨 CRITICAL WORKER ERROR: {str(e)}")
            time.sleep(5)

def start_worker():
    global WORKER_STARTED
    if WORKER_STARTED:
        return

    # ป้องกันรันซ้ำหลาย Process (บน Linux/Production)
    if fcntl:
        try:
            lock_fp = open(LOCK_FILE, "w")
            fcntl.flock(lock_fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (BlockingIOError, IOError):
            print("Worker already running in another process")
            return

    t = threading.Thread(target=worker_loop, daemon=True)
    t.start()
    WORKER_STARTED = True
    print("Single worker started")

# เริ่มต้น Worker (จะถูกป้องกันด้วย File Lock หากมีการรันหลาย Process)
start_worker()

# อนุญาตอัปโหลดไฟล์รูป (เราใช้แค่อ่านเป็น bytes ไม่ได้เก็บไฟล์ถาวร)
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png"}


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
@login_required
def index():
    config = load_config()
    pages = config.get("pages", [])
    active_pages = [p for p in pages if p.get("active", True)]

    enriched_pages = []
    now_ts = time.time()

    for p in pages:
        pid = p.get("id")
        
        # ดึงจาก Cache ถ้ายังไม่หมดอายุ
        cache_entry = PAGE_CACHE.get(pid)
        if cache_entry and (now_ts - cache_entry["timestamp"] < CACHE_TTL):
            token_status = cache_entry["token_status"]
            expire_text = cache_entry["token_expire"]
            picture_url = cache_entry["picture_url"]
        else:
            # ใช้จาก config (ถ้ามี) หรือค่าเริ่มต้น
            token_status = p.get("token_status_cache", "ยังไม่ได้ตรวจสอบ")
            expire_text = p.get("token_expire_cache", "-")
            picture_url = p.get("picture_url_cache") or None

        enriched = dict(p)
        enriched["token_status"] = token_status
        enriched["token_expire"] = expire_text
        enriched["picture_url"] = picture_url
        enriched_pages.append(enriched)

    return render_template("index.html", pages=enriched_pages, active_pages=active_pages)


@app.route("/api/page_status/<page_id>", methods=["POST"])
@login_required
def api_page_status(page_id):
    """Route สำหรับให้กด Check Status ด้วยตัวเอง (Manual Check)"""
    config = load_config()
    pages = config.get("pages", [])
    p = next((page for page in pages if page["id"] == page_id), None)
    
    if not p:
        return {"success": False, "error": "ไม่พบ Page"}

    token = p.get("token")
    if not token:
        return {"success": False, "error": "ไม่มี Token"}

    if not can_call_api(f"status_{page_id}"):
        return {"success": False, "error": "กรุณารอ 5 นาที ก่อนเรียกตรวจสอบใหม่ (API Cooldown)"}

    try:
        # 1. ตรวจสอบสถานะ Token
        token_status = "❌ ใช้งานไม่ได้"
        expire_text = "ไม่พบข้อมูล"
        
        res = test_token(token)
        if res.get("success"):
            debug_data = res.get("debug", {}).get("data", {})
            is_valid = debug_data.get("is_valid", False)
            expires_at = debug_data.get("expires_at")

            token_status = "✅ ใช้งานได้" if is_valid else "❌ ใช้งานไม่ได้"
            
            if expires_at:
                exp_dt = datetime.fromtimestamp(expires_at)
                days_left = (exp_dt.date() - datetime.now().date()).days
                if days_left > 0:
                    expire_text = f"เหลือ {days_left} วัน (หมดอายุ {exp_dt:%Y-%m-%d})"
                elif days_left == 0:
                    expire_text = f"หมดอายุวันนี้ ({exp_dt:%Y-%m-%d})"
                else:
                    expire_text = f"หมดอายุแล้ว ({exp_dt:%Y-%m-%d})"
            else:
                expire_text = "ไม่มีวันหมดอายุ (Long-lived)"
        else:
            token_status = "❌ ผิดพลาด"
            expire_text = res.get("error", "ตรวจสอบไม่สำเร็จ")

        # 2. ดึงรูปโปรไฟล์
        picture_url = get_page_picture(token)

        # 3. อัปเดตลง Cache (In-memory)
        PAGE_CACHE[page_id] = {
            "token_status": token_status,
            "token_expire": expire_text,
            "picture_url": picture_url,
            "timestamp": time.time()
        }

        # 4. บันทึกลง config.json (Persistent Cache)
        p["token_status_cache"] = token_status
        p["token_expire_cache"] = expire_text
        p["picture_url_cache"] = picture_url
        p["last_checked"] = time.time()
        save_config(config)

        return {
            "success": True, 
            "token_status": token_status, 
            "token_expire": expire_text, 
            "picture_url": picture_url
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.route("/pages/add", methods=["GET", "POST"])
@login_required
def add_page_view():
    test_result = None
    token_input = ""
    name_input = ""

    if request.method == "POST":
        action = request.form.get("action")
        name_input = request.form.get("name") or "Page ใหม่"
        token_input = request.form.get("token") or ""

        if not token_input:
            flash("กรุณาใส่ Access Token", "danger")
        else:
            if action == "test":
                if not can_call_api(f"token_test_{token_input[:10]}"):
                    flash("กรุณารอ 5 นาที ก่อนทดสอบ Token อีกครั้ง", "warning")
                    return render_template(
                        "pages_add.html",
                        test_result=test_result,
                        token_input=token_input,
                        name_input=name_input,
                    )
                
                test_result = test_token(token_input)
                if test_result.get("success"):
                    flash("ทดสอบ Token สำเร็จ", "success")
                else:
                    flash(f"ทดสอบ Token ไม่สำเร็จ: {test_result.get('error')}", "danger")
            elif action == "save":
                # SEO Fields
                district = request.form.get("district") or ""
                province = request.form.get("province") or ""
                areas_text = request.form.get("areas") or ""
                areas = [a.strip() for a in areas_text.split('\n') if a.strip()]

                result = add_page(name_input, token_input, district=district, province=province, areas=areas)

                if result.get("success"):
                    flash(f"เพิ่ม Page '{result['page']['name']}' สำเร็จ", "success")
                    return redirect(url_for("index"))
                else:
                    flash(f"ไม่สามารถเพิ่ม Page ได้: {result.get('error')}", "danger")

    return render_template(
        "pages_add.html",
        test_result=test_result,
        token_input=token_input,
        name_input=name_input,
    )


@app.route("/pages/manage", methods=["GET", "POST"])
@app.route("/pages/manage/<page_id>", methods=["GET", "POST"])
@login_required
def manage_pages(page_id=None):
    config = load_config()
    pages = config.get("pages", [])

    if not pages:
        flash("ยังไม่มี Page ในระบบ", "warning")
        return redirect(url_for("add_page_view"))

    if page_id is None:
        page_id = request.args.get("page_id")
        if page_id is None and pages:
            page_id = pages[0]["id"]

    selected = next((p for p in pages if p["id"] == page_id), pages[0])

    if request.method == "POST":
        if "update" in request.form:
            new_name = request.form.get("name")
            new_token = request.form.get("token") or None
            is_active = request.form.get("active") == "on"
            
            # New SEO Fields
            new_district = request.form.get("district") or ""
            new_province = request.form.get("province") or ""
            areas_text = request.form.get("areas") or ""
            new_areas = [a.strip() for a in areas_text.split('\n') if a.strip()]

            result = update_page(page_id, name=new_name, token=new_token, active=is_active,
                                district=new_district, province=new_province, areas=new_areas)
            if result.get("success"):
                flash("อัปเดต Page สำเร็จ", "success")
                return redirect(url_for("manage_pages", page_id=page_id))
            else:
                flash(f"ไม่สามารถอัปเดตได้: {result.get('error')}", "danger")
        elif "delete" in request.form:
            delete_page(page_id)
            flash("ลบ Page สำเร็จ", "success")
            return redirect(url_for("index"))

    return render_template("pages_manage.html", pages=pages, selected=selected)


@app.route("/api/test/<page_id>")
@login_required
def api_test(page_id):
    # 1. เช็ค Cache ก่อน
    now = time.time()
    if page_id in TEST_CACHE:
        cache = TEST_CACHE[page_id]
        if now - cache["timestamp"] < TEST_TTL:
            return render_template(
                "api_test.html",
                page=cache["page"],
                token_info=cache["token_info"],
                page_info=cache["page_info"],
                posts_info=cache["posts_info"],
                cached=True
            )

    config = load_config()
    pages = config.get("pages", [])
    page = next((p for p in pages if p["id"] == page_id), None)
    if not page:
        flash("ไม่พบ Page", "danger")
        return redirect(url_for("index"))

    # 2. เช็ค Cooldown
    if not can_call_api(f"test_{page_id}"):
        flash("กรุณารอ 5 นาที ก่อนเรียกข้อมูลชุดใหญ่ใหม่อีกครั้ง (API Cooldown)", "warning")
        return redirect(url_for("index"))

    token = page.get("token")
    token_info = test_token(token)
    page_info = get_page_info(token)
    posts_info = get_posts(token, limit=5)

    # 3. บันทึก Cache
    TEST_CACHE[page_id] = {
        "page": page,
        "token_info": token_info,
        "page_info": page_info,
        "posts_info": posts_info,
        "timestamp": now
    }

    return render_template(
        "api_test.html",
        page=page,
        token_info=token_info,
        page_info=page_info,
        posts_info=posts_info,
    )


@app.route("/post", methods=["GET", "POST"])
@login_required
def post_view():
    config = load_config()
    pages = [p for p in config.get("pages", []) if p.get("active", True)]
    results: List[Tuple[dict, dict]] | None = None

    if request.method == "POST":
        post_mode = request.form.get("post_mode", "same")
        results = []
        history = load_history()
        items = history.get("items", [])
        
        # --- Mode 1: Post Same Content to Multiple Pages ---
        if post_mode == "same":
            selected_ids = request.form.getlist("pages")
            message = request.form.get("message") or ""
            link = request.form.get("link") or None
            files = request.files.getlist("images")

            if not selected_ids:
                flash("กรุณาเลือกอย่างน้อย 1 เพจ", "danger")
            elif not message and not any(f.filename for f in files):
                 flash("กรุณาใส่ข้อความหรือเลือกรูปภาพ", "danger")
            else:
                image_payloads = []
                for f in files:
                    if not f or not allowed_file(f.filename):
                        continue
                    filename = secure_filename(f.filename)
                    f.seek(0)
                    data = f.read()
                    image_payloads.append({"name": filename, "data": data})

                for p in pages:
                    if p["id"] not in selected_ids:
                        continue
                    token = p.get("token")
                    
                    if image_payloads:
                        final_message = message if not link else f"{message}\n\n{link}"
                    else:
                        final_message = message

                    # เพิ่มเข้า Queue แบบมีไฟล์รองรับ (กันหาย)
                    add_to_queue({
                        "page_id": p.get("page_id"),
                        "page_name": p.get("name"),
                        "token": token,
                        "message": final_message,
                        "link": link,
                        "images": image_payloads
                    })
                    
                    results.append((p, {"success": True, "queued": True}))
                
                flash(f"✅ เพิ่ม {len(results)} โพสต์ลงในคิวแล้ว ระบบจะทยอยส่งโพสต์ทุกๆ 15-25 วินาที", "success")

        # --- Mode 2: Post Individual Content ---
        elif post_mode == "individual":
            selected_ids = request.form.getlist("pages_indiv")
            
            if not selected_ids:
                flash("กรุณาเลือกอย่างน้อย 1 เพจ", "danger")
            else:
                for p in pages:
                    if p["id"] not in selected_ids:
                        continue
                    
                    message = request.form.get(f"message_{p['id']}") or ""
                    link = request.form.get(f"link_{p['id']}") or None
                    files = request.files.getlist(f"images_{p['id']}")
                    
                    if not message and not any(f.filename for f in files):
                        results.append((p, {"success": False, "error": "กรุณาใส่ข้อความหรือรูปภาพ"}))
                        continue

                    token = p.get("token")
                    image_payloads = []
                    for f in files:
                        if not f or not allowed_file(f.filename):
                            continue
                        filename = secure_filename(f.filename)
                        f.seek(0)
                        data = f.read()
                        image_payloads.append({"name": filename, "data": data})
                    
                    if image_payloads:
                        final_message = message if not link else f"{message}\n\n{link}"
                    else:
                        final_message = message

                    # เพิ่มเข้า Queue แบบมีไฟล์รองรับ (กันหาย)
                    add_to_queue({
                        "page_id": p.get("page_id"),
                        "page_name": p.get("name"),
                        "token": token,
                        "message": final_message,
                        "link": link,
                        "images": image_payloads
                    })
                    results.append((p, {"success": True, "queued": True}))

                flash(f"✅ เพิ่ม {len(results)} โพสต์ลงในคิวแล้ว (Mode: Individual)", "success")

        # --- Mode 3: SEO Auto-Gen (with Preview) ---
        elif post_mode == "seo":
            from seo_generator import generate_seo_content
            from werkzeug.utils import secure_filename

            action = request.form.get("action")
            selected_ids = request.form.getlist("pages_seo")
            service = request.form.get("seo_service") or ""
            phone = request.form.get("seo_phone") or ""
            # ลบ "โทร. " หรือ "โทร " ออกถ้าผู้ใช้พิมพ์มาเอง เพื่อให้ระบบใส่ให้แบบมาตรฐานไม่ซ้ำซ้อน
            phone = phone.replace("โทร. ", "").replace("โทร. ", "").replace("โทร ", "").strip()
            template = request.form.get("seo_template") or ""
            link = request.form.get("seo_link") or None
            files = request.files.getlist("seo_images")

            if not selected_ids:
                flash("กรุณาเลือกอย่างน้อย 1 เพจ", "danger")
            elif not service and not template:
                flash("กรุณาระบุบริการ หรือ Template", "danger")
            
            # Step 1: สร้าง Preview
            elif action == "seo_preview":
                seo_previews = []
                target_pages = [p for p in pages if p["id"] in selected_ids]
                
                # จัดการรูปภาพชั่วคราว
                temp_image_paths = []
                for f in files:
                    if f and allowed_file(f.filename):
                        filename = f"{int(time.time())}_{secure_filename(f.filename)}"
                        filepath = os.path.join(TEMP_DIR, filename)
                        f.save(filepath)
                        temp_image_paths.append(filename)
                
                for page in target_pages:
                    if template:
                        district = page.get("district", "")
                        province = page.get("province", "")
                        # ตรวจสอบว่าเบอร์มี โทร. นำหน้าหรือยัง
                        clean_phone = phone
                        if clean_phone and not clean_phone.startswith("โทร."):
                            clean_phone = f"โทร. {clean_phone}"
                            
                        message = template.replace("{บริการ}", service) \
                                          .replace("{อำเภอ}", district) \
                                          .replace("{จังหวัด}", province) \
                                          .replace("{เบอร์โทร}", clean_phone)
                        new_count = page.get("consecutive_nearby_count", 0)
                    else:
                        message, new_count = generate_seo_content(service, page, phone)
                    
                    seo_previews.append({
                        "page_id": page["id"],
                        "page_name": page["name"],
                        "message": message,
                        "new_count": new_count
                    })
                
                return render_template("post.html", 
                                        pages=pages, 
                                        seo_previews=seo_previews,
                                        seo_service=service,
                                        seo_phone=phone,
                                        seo_template=template,
                                        seo_link=link,
                                        seo_temp_images=temp_image_paths,
                                        active_mode="seo")

            # Step 2: ยืนยันโพสต์จริง (หลังจาก Edit)
            elif action == "seo_confirm":
                image_payloads = []
                
                # ลองโหลดรูปใหม่ที่แนบมา
                for f in files:
                    if f and allowed_file(f.filename):
                        filename = secure_filename(f.filename)
                        f.seek(0)
                        data = f.read()
                        image_payloads.append({"name": filename, "data": data})
                
                # ถ้าไม่มีรูปใหม่ ให้ดึงรูปจาก temp_images ที่ส่งกลับมาทาง Hidden Input
                if not image_payloads:
                    temp_images = request.form.getlist("seo_temp_images_hidden")
                    for filename in temp_images:
                        filepath = os.path.join(TEMP_DIR, filename)
                        if os.path.exists(filepath):
                            with open(filepath, "rb") as f:
                                data = f.read()
                                # ดึงชื่อไฟล์เดิมออก (ตัด timestamp นำหน้าออก)
                                original_name = filename.split("_", 1)[-1] if "_" in filename else filename
                                image_payloads.append({"name": original_name, "data": data})
                            # ลบไฟล์ temp ทิ้งหลังใช้งานเสร็จ (optional, หรือจะเก็บไว้เผื่อกดพลาด)
                            # os.remove(filepath)

                config_updated = False
                for p_id in selected_ids:
                    # ดึงข้อความที่แก้ไขมาแล้วจาก Form
                    edited_message = request.form.get(f"seo_msg_{p_id}")
                    new_count = request.form.get(f"seo_count_{p_id}", type=int, default=0)
                    
                    page = next((p for p in pages if p["id"] == p_id), None)
                    if not page or not edited_message:
                        continue

                    token = page.get("token")
                    final_message = edited_message if not link else f"{edited_message}\n\n{link}"

                    # บันทึก count กลับไปถ้าเปลี่ยน
                    if page.get("consecutive_nearby_count") != new_count:
                        page["consecutive_nearby_count"] = new_count
                        config_updated = True

                    add_to_queue({
                        "page_id": page.get("page_id"),
                        "page_name": page.get("name"),
                        "token": token,
                        "message": final_message,
                        "link": link,
                        "images": image_payloads
                    })
                    results.append((page, {"success": True, "queued": True}))

                if config_updated:
                    save_config(config)
                
                flash(f"✅ ยืนยันโพสต์ SEO {len(results)} รายการลงในคิวแล้ว", "success")

    return render_template("post.html", pages=pages, results=results, active_mode=request.form.get("post_mode", "same"))


@app.route("/history", methods=["GET", "POST"])
@login_required
def history_view():
    history = load_history()
    items = history.get("items", [])
    
    # ดึงงานที่ยังค้างอยู่ในคิวมาแสดงด้วย
    pending_jobs = []
    if os.path.exists(JOBS_FILE):
        try:
            with open(JOBS_FILE, "r", encoding="utf-8") as f:
                pending_jobs = json.load(f)
        except:
            pass

    if request.method == "POST" and "delete" in request.form:
        post_id = request.form.get("post_id")
        page_id = request.form.get("page_id")

        # หา token ของ page นี้
        config = load_config()
        pages = config.get("pages", [])
        page = next((p for p in pages if str(p.get("page_id")) == str(page_id)), None)

        if not page or not page.get("token"):
            flash("ไม่พบข้อมูล Page หรือ Token สำหรับลบโพสต์", "danger")
        else:
            res = delete_post(page.get("token"), post_id)
            if res.get("success"):
                with HISTORY_LOCK:
                    current_history = load_history()
                    current_items = current_history.get("items", [])
                    # มาร์กใน history ว่าลบแล้ว
                    for h in current_items:
                        if h.get("post_id") == post_id:
                            h["deleted"] = True
                    current_history["items"] = current_items
                    save_history(current_history)
                flash("ลบโพสต์บน Facebook สำเร็จ", "success")
            else:
                flash(f"ไม่สามารถลบโพสต์ได้: {res.get('error')}", "danger")

    # แสดงโพสต์ล่าสุดก่อน
    items_sorted = sorted(items, key=lambda x: x.get("created_at", ""), reverse=True)
    
    # ดึงรูปโปรไฟล์ (เฉพาะที่เก็บใน Cache/Config เท่านั้น ห้ามเรียก API ใหม่)
    config = load_config()
    pages = config.get("pages", [])
    page_pictures = {}
    for p in pages:
        p_id = p.get("id")
        p_page_id = str(p.get("page_id", ""))
        
        # ค้นหาจาก Cache ก่อน
        cache_entry = PAGE_CACHE.get(p_id)
        if cache_entry and cache_entry.get("picture_url"):
            page_pictures[p_page_id] = cache_entry["picture_url"]
        else:
            # ใช้จาก Config
            pic = p.get("picture_url_cache")
            if pic:
                page_pictures[p_page_id] = pic
    
    # เพิ่มรูปโปรไฟล์ให้กับแต่ละ history item
    for item in items_sorted:
        page_id = str(item.get("page_id", ""))
        item["picture_url"] = page_pictures.get(page_id)
    
    return render_template("history.html", items=items_sorted, pending_jobs=pending_jobs)


if __name__ == "__main__":
    # รัน Flask dev server
    app.run(host="0.0.0.0", port=5000, debug=True)