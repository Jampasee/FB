import requests
import json

# ข้อมูลของคุณที่ได้จากหน้าจอ
APP_ID = "2118104875612088"
APP_SECRET = "87e363e347f10fc1c235259348e2a80e"
BASE_URL = "https://graph.facebook.com/v18.0"

def exchange_token():
    print("=== Facebook Permanent Token Tool ===")
    print(f"App ID: {APP_ID}")
    print("-" * 35)
    
    # 1. รับ Short-lived Token จากผู้ใช้
    short_token = input("กรุณาวาง Short-lived Token (จาก Graph API Explorer): ").strip()
    if not short_token:
        print("❌ ต้องใส่ Token ครับ")
        return

    try:
        # 2. แลกเป็น Long-lived User Token (60 วัน)
        print("\n⏳ กำลังแลกเป็น Long-lived User Token...")
        params = {
            "grant_type": "fb_exchange_token",
            "client_id": APP_ID,
            "client_secret": APP_SECRET,
            "fb_exchange_token": short_token
        }
        resp = requests.get(f"{BASE_URL}/oauth/access_token", params=params)
        resp.raise_for_status()
        long_user_token = resp.json().get("access_token")
        
        if not long_user_token:
            print("❌ ไม่ได้รับ Long-lived Token กลับมา")
            return

        # 3. แลกเป็น Page Access Tokens (จะกลายเป็นแบบถาวร)
        print("⏳ กำลังดึง Page Access Tokens แบบถาวร...")
        page_params = {
            "access_token": long_user_token,
            "fields": "name,id,access_token"
        }
        page_resp = requests.get(f"{BASE_URL}/me/accounts", params=page_params)
        page_resp.raise_for_status()
        pages = page_resp.json().get("data", [])

        if not pages:
            print("❌ ไม่พบ Page ที่คุณดูแลอยู่ หรือ Permission ไม่เพียงพอ")
            print("คำแนะนำ: ตรวจสอบว่าใน Graph API Explorer ได้เลือกสิทธิ์ pages_manage_posts และ pages_read_engagement หรือยัง")
            return

        print(f"\n✅ สำเร็จ! พบทั้งหมด {len(pages)} เพจ ดังนี้:\n")
        print("=" * 60)
        for page in pages:
            print(f"เพจ: {page['name']}")
            print(f"ID  : {page['id']}")
            print(f"Token (คัดลอกอันนี้ไปใช้ครับ):")
            print(f"{page['access_token']}")
            print("-" * 60)
        
        print("\nนำ Token ด้านบนนี้ไปใส่ในหน้า 'จัดการ Page' ของระบบคุณได้เลยครับ!")

    except requests.exceptions.HTTPError as e:
        print(f"\n❌ เกิดข้อผิดพลาดจาก Facebook API: {e.response.text}")
    except Exception as e:
        print(f"\n❌ เกิดข้อผิดพลาด: {str(e)}")

if __name__ == "__main__":
    exchange_token()
    input("\nกด Enter เพื่อปิดโปรแกรม...")
