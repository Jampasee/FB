const CACHE_NAME = 'fb-multipost-v2';
const ASSETS = [
    '/',
    '/static/css/style.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(ASSETS);
        })
    );
});

self.addEventListener('fetch', (event) => {
    // ข้ามการ Intercept สำหรับรูปภาพชั่วคราว SEO เพื่อป้องกันปัญหาใน PWA
    if (event.request.url.includes('/static/temp_uploads/')) {
        return;
    }

    event.respondWith(
        caches.match(event.request).then((response) => {
            return response || fetch(event.request);
        })
    );
});
