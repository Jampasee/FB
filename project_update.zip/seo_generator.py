import random
from typing import List, Dict, Tuple

# --- Sentence Pools (Grouped by Intent) ---

# Intents: technician, price, repair, nearby, portfolio
# We'll randomly select one intent per generation.

HEADLINES = {
    "technician": [
        "🔥 {service} โดยทีมช่างมืออาชีพ {target_location}",
        "✅ หาช่าง{service} {target_location} ประสบการณ์สูง",
        "👷‍♂️ ทีมงาน{service} {target_location} พร้อมให้บริการ",
        "🏆 ช่าง{service} {target_location} งานดี จบไว",
        "⭐ {service} โดยช่างเฉพาะทาง {target_location}",
    ],
    "price": [
        "� {service} {target_location} ราคาถูก เป็นกันเอง",
        "🏷️ โปรโมชั่น {service} ใน {target_location} ราคาพิเศษ",
        "✨ {service} {target_location} ประเมินราคาฟรี ไม่มีบวกเพิ่ม",
        "💸 มองหา {service} ราคาดีที่สุดใน {target_location}",
        "📉 {service} {target_location} งบน้อยก็ทำได้",
    ],
    "repair": [
        "🛠️ รับซ่อม/แก้ไข {service} {target_location} จบทุกปัญหา",
        "⚠️ ปัญหา {service} ให้เราดูแล เขต {target_location}",
        "� บริการซ่อม {service} ด่วน ใน {target_location}",
        "🚑 {service} ชำรุด/เสียหาย เรียกช่าง {target_location}",
        "🛑 หมดกังวลเรื่อง {service} พัง ชาว {target_location}",
    ],
    "nearby": [
        "📍 {service} ใกล้บ้านท่าน {target_location}",
        "🚀 ช่าง{service} {target_location} ถึงไว ภายใน 1 ชม.",
        "� เรียกช่าง{service} {target_location} ใกล้ๆ ดูแลทั่วถึง",
        "🛵 บริการ {service} เดลิเวอรี่ แถว {target_location}",
        "🏘️ ทีมงาน {service} ประจำพื้นที่ {target_location}",
    ],
    "portfolio": [
        "📸 รีวิวงาน {service} ลูกค้าจริง {target_location}",
        "🌟 โชว์ผลงาน {service} สวยๆ ใน {target_location}",
        "✨ ตัวอย่างงาน {service} {target_location} การันตีคุณภาพ",
        "🖼️ ภาพงานติดตั้ง {service} พื้นที่ {target_location}",
        "🏗️ ส่งงาน {service} ล่าสุด ใน {target_location}",
    ]
}

INTROS = {
    "technician": [
        "เราคือทีมช่างรับ{service} ในเขต{target_location} ที่มีความชำนาญสูง",
        "ต้องการช่าง{service} ฝีมือดีใน {target_location} ทีมงานเราพร้อมดูแล",
        "บริการ{service} โดยช่างพื้นที่ {target_location} ไว้ใจได้ 100%",
        "ทีมงานคุณภาพ พร้อมลุยงาน {service} ทั่ว {target_location}",
    ],
    "price": [
        "รับ{service} ในเขต{target_location} ราคามิตรภาพ คุยง่าย",
        "อยากได้ {service} ดีและถูกใน {target_location} ปรึกษาเราก่อนได้",
        "บริการ{service} {target_location} ในราคาสบายกระเป๋า งบไม่บานปลาย",
        "คุ้มค่า คุ้มราคา กับบริการ {service} ใน {target_location}",
    ],
    "repair": [
        "รับแก้ปัญหา{service} ทุกอาการ ในพื้นที่ {target_location}",
        "ซ่อมด่วน ซ่อมจบ งาน{service} {target_location} โดยช่างเฉพาะทาง",
        "หาก{service} มีปัญหา เรียกเรา ทีมงาน {target_location} พร้อมเข้าหน้างาน",
        "บริการดูแลระบบ {service} ครบวงจร ชาว {target_location}",
    ],
    "nearby": [
        "เรียกช่าง{service} ใกล้ฉัน พื้นที่ {target_location} ไปไว",
        "บริการด่วน {service} สำหรับคน {target_location} โดยเฉพาะ",
        "ช่าง{service} ประจำเขต {target_location} อยู่ใกล้ เรียกง่าย",
        "ดูแลทั่วถึง {service} ใน {target_location} และระแวกใกล้เคียง",
    ],
    "portfolio": [
        "ขอนำเสนอผลงาน {service} ล่าสุดจากหน้างาน {target_location}",
        "พาชมผลงานติดตั้ง {service} สวยๆ ที่ {target_location} ครับ",
        "ส่งงานเรียบร้อยกับบริการ {service} ให้ลูกค้า {target_location}",
        "ขอขอบคุณลูกค้า {target_location} ที่ไว้วางใจให้เราดูแล {service}",
    ]
}

# --- Common Pools (Can be used across intents) ---

DETAILS = [
    "งานดี งานไว ใส่ใจทุกรายละเอียด โดยช่างประสบการณ์สูง",
    "ใช้วัสดุเกรด A แข็งแรง ทนทาน ใช้งานได้ยาวนาน",
    "รับประกันงานติดตั้ง ไม่ทิ้งงาน ราคามาตรฐาน",
    "ประเมินหน้างานฟรี ปรึกษาได้ตลอด 24 ชม.",
    "ทีมงานมืออาชีพ เครื่องมือครบครัน จบงานไว",
    "เน้นคุณภาพและความสวยงาม ถูกใจลูกค้าแน่นอน",
    "ราคาคุยกันได้ ไม่บานปลาย จบจริง",
    "ยินดีให้คำปรึกษาและออกแบบตามงบประมาณ",
    "ประสบการณ์ยาวนาน จบมาแล้วทุกรูปแบบงาน",
]

CTAS = [
    "📞 สนใจติดต่อสอบถาม โทร. {phone}",
    "👉 สอบถามราคา/นัดดูหน้างาน โทร. {phone}",
    "📌 จองคิวงานด่วน โทร. {phone}",
    "💬 ปรึกษาฟรี ไม่มีค่าใช้จ่าย โทร. {phone}",
    "✅ ติดต่อช่างโดยตรง โทร. {phone} (คุณแชมป์)",
    "☎️ โทร. {phone} พร้อมให้บริการทุกวัน",
]

LOCAL_REINFORCEMENTS = [
    "ให้บริการในพื้นที่{district}โดยตรง",
    "ช่างอยู่ใกล้{district} เรียกง่าย ไปไว",
    "รับงานในเขต{district} {province} และระแวกใกล้เคียง",
    "เราเป็นร้านท้องถิ่นใน {district} {province} ดูแลกันเอง",
    "คน {district} การันตีผลงาน บริการประทับใจ",
    "พร้อมดูแลลูกค้าใน {district} และ {province} ทั้งหมด",
    "วิ่งงานทั่ว {district} ไม่เกี่ยงงาน",
]

# --- Generator Logic ---

def generate_seo_content(service: str, page_config: Dict, phone: str) -> Tuple[str, int]:
    """
    Generates unique SEO content based on page configuration and search intent rules.
    Args:
        service (str): Service name.
        page_config (Dict): Page data including district, province, areas, etc.
        phone (str): Contact phone number.
    Returns:
        Tuple[str, int]: (Generated Content, Updated Consecutive Count)
    """
    
    district = page_config.get("district", "").strip()
    province = page_config.get("province", "").strip()
    areas = page_config.get("areas", [])
    consecutive_nearby = page_config.get("consecutive_nearby_count", 0)
    
    # Validation
    if not district:
        return f"{service} บริการดี โทร {phone}", 0

    # --- Step 1: Select Search Intent ---
    intent = random.choice(["technician", "price", "repair", "nearby", "portfolio"])

    # --- Step 2: Select Target Location (70/30 Logic) ---
    target_location_str = ""
    new_consecutive_count = consecutive_nearby

    use_nearby = False
    if consecutive_nearby >= 2:
        use_nearby = False
        new_consecutive_count = 0
    elif areas and random.random() < 0.3:
        use_nearby = True
        new_consecutive_count += 1
    else:
        use_nearby = False
        new_consecutive_count = 0

    if use_nearby:
        area = random.choice(areas).strip()
        target_location_str = f"{area} {province}"
    else:
        target_location_str = f"{district} {province}"

    # --- Step 3: Prepare Keywords & Components ---
    
    # Select pools based on intent
    headline_pool = HEADLINES.get(intent, HEADLINES["technician"])
    intro_pool = INTROS.get(intent, INTROS["technician"])

    headline = random.choice(headline_pool).format(service=service, target_location=target_location_str)
    intro = random.choice(intro_pool).format(service=service, target_location=target_location_str)
    
    detail_1 = random.choice(DETAILS)
    detail_2 = random.choice([d for d in DETAILS if d != detail_1])
    
    reinforcement = random.choice(LOCAL_REINFORCEMENTS).format(district=district, province=province)
    
    cta = random.choice(CTAS).format(phone=phone)

    # --- Step 4: Choose Structure (Variation) ---
    structure_type = random.choice(["A", "B", "C"])
    parts = []

    if structure_type == "A":
        # Standard: Headline -> Intro -> Details -> Reinforce -> CTA
        parts = [headline, intro, f"✅ {detail_1}", f"✅ {detail_2}", reinforcement, cta]
    elif structure_type == "B":
        # Direct: Intro -> Details -> Reinforce -> CTA (No Headline)
        parts = [intro, f"✅ {detail_1}", f"✅ {detail_2}", reinforcement, cta]
    elif structure_type == "C":
        # Punchy: Headline -> Reinforce -> Details -> CTA
        parts = [headline, reinforcement, f"✅ {detail_1}", f"✅ {detail_2}", cta]

    content = "\n\n".join(filter(None, parts))

    # --- Step 5: Keyword Density Check & Fix ---
    count_service = content.count(service)
    count_district = content.count(district)
    count_province = content.count(province)

    if count_service < 2 or count_district < 2 or count_province < 1:
        # Fallback Fixer
        fixer = f"\n\n🛠️ รับ{service} {district} {province} โดยทีมงานมืออาชีพ โทร. {phone}"
        content += fixer
        
    # --- Step 6: Phone Duplication Fix ---
    # Ensure phone number appears ONLY ONCE (keep the last/CTA occurrence)
    if phone and content.count(phone) > 1:
        # Split into parts by phone number
        raw_parts = content.split(phone)
        # The last part is what follows the last phone number
        suffix = raw_parts[-1]
        # All parts except the last one (these come before the last phone number)
        prefixes = raw_parts[:-1]
        
        cleaned_prefixes = []
        for p in prefixes:
            # Clean up common "Call" labels that might become orphaned
            temp = p
            for label in ["โทร.", "โทร:", "โทรเลย:", "โทรเลย", "โทร"]:
                if temp.strip().endswith(label):
                    # Remove the label if it's right before where the phone was
                    idx = temp.rstrip().rfind(label)
                    temp = temp[:idx].rstrip()
            cleaned_prefixes.append(temp)
        
        # Reconstruct: Join prefixes (now without phones or orphaned labels) 
        # then add the last phone with 'โทร. ' prefix and the final suffix
        content = "".join(cleaned_prefixes).rstrip()
        if content and not content.endswith("\n"):
            content += "\n\n"
        content += "โทร. " + phone + suffix

    return content, new_consecutive_count
