import requests
import json
import uuid
import os
from datetime import datetime
from typing import Dict, Optional, List

# หา Path ของไฟล์ข้อมูลโดยอ้างอิงจากตำแหน่งของไฟล์ utils.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, 'config.json')
HISTORY_PATH = os.path.join(BASE_DIR, 'history.json')

BASE_URL = "https://graph.facebook.com/v18.0"

def test_token(token: str) -> Dict:
    """ทดสอบ Token และดึงข้อมูล Page"""
    try:
        # ตรวจสอบ Token Debug
        response = requests.get(
            f"{BASE_URL}/debug_token",
            params={
                "input_token": token,
                "access_token": token
            }
        )
        response.raise_for_status()
        debug_data = response.json()
        
        # ดึงข้อมูล Page
        page_data = None
        if debug_data.get('data', {}).get('is_valid'):
            page_response = requests.get(
                f"{BASE_URL}/me",
                params={
                    "access_token": token,
                    "fields": "id,name,about,fan_count,link,category"
                }
            )
            if page_response.status_code == 200:
                page_data = page_response.json()
        
        return {
            "success": True,
            "debug": debug_data,
            "page": page_data
        }
    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if hasattr(e, 'response') and e.response is not None:
            try:
                error_data = e.response.json()
                error_msg = error_data.get('error', {}).get('message', str(e))
            except:
                error_msg = e.response.text
        return {
            "success": False,
            "error": error_msg
        }

def get_page_info(token: str) -> Dict:
    """ดึงข้อมูล Page"""
    try:
        response = requests.get(
            f"{BASE_URL}/me",
            params={
                "access_token": token,
                "fields": "id,name,about,fan_count,link,category,phone,verification_status"
            }
        )
        response.raise_for_status()
        return {
            "success": True,
            "data": response.json()
        }
    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if hasattr(e, 'response') and e.response is not None:
            try:
                error_data = e.response.json()
                error_msg = error_data.get('error', {}).get('message', str(e))
            except:
                error_msg = e.response.text
        return {
            "success": False,
            "error": error_msg
        }

def get_page_picture(token: str) -> Optional[str]:
    """ดึง URL รูปโปรไฟล์ของ Page"""
    try:
        response = requests.get(
            f"{BASE_URL}/me",
            params={
                "access_token": token,
                "fields": "picture"
            }
        )
        response.raise_for_status()
        data = response.json()
        picture = data.get("picture", {})
        if isinstance(picture, dict):
            picture_data = picture.get("data", {})
            return picture_data.get("url")
        return None
    except requests.exceptions.RequestException:
        return None

def get_posts(token: str, limit: int = 5) -> Dict:
    """ดึงโพสต์ของ Page"""
    try:
        response = requests.get(
            f"{BASE_URL}/me/posts",
            params={
                "access_token": token,
                "fields": "id,message,created_time",
                "limit": limit
            }
        )
        response.raise_for_status()
        return {
            "success": True,
            "data": response.json()
        }
    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if hasattr(e, 'response') and e.response is not None:
            try:
                error_data = e.response.json()
                error_msg = error_data.get('error', {}).get('message', str(e))
            except:
                error_msg = e.response.text
        return {
            "success": False,
            "error": error_msg
        }

def create_post(token: str, message: str, link: Optional[str] = None) -> Dict:
    """โพสต์ข้อความไปยัง Facebook Page (ข้อความ + ลิงก์)"""
    try:
        params = {
            "access_token": token,
            "message": message
        }
        if link:
            params["link"] = link
        
        response = requests.post(
            f"{BASE_URL}/me/feed",
            params=params
        )
        response.raise_for_status()
        data = response.json()
        return {
            "success": True,
            "data": data,
            "post_id": data.get('id'),
            "post_url": f"https://www.facebook.com/{data.get('id')}" if data.get('id') else None
        }
    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if hasattr(e, 'response') and e.response is not None:
            try:
                error_data = e.response.json()
                error_msg = error_data.get('error', {}).get('message', str(e))
            except:
                error_msg = e.response.text
        return {
            "success": False,
            "error": error_msg
        }


def create_multi_image_post(token: str, message: str, images: List[Dict]) -> Dict:
    """
    โพสต์ข้อความพร้อมหลายรูปภาพไปยัง Facebook Page
    images: list ของ {"name": str, "data": bytes}
    """
    if not images:
        return {
            "success": False,
            "error": "ไม่มีรูปภาพที่ใช้โพสต์"
        }
    
    uploaded_ids: List[str] = []
    
    try:
        # 1) อัปโหลดรูปแบบ unpublished photos
        for img in images:
            files = {
                "source": (img["name"], img["data"])
            }
            params = {
                "access_token": token,
                "published": "false"
            }
            resp = requests.post(
                f"{BASE_URL}/me/photos",
                params=params,
                files=files
            )
            resp.raise_for_status()
            photo_data = resp.json()
            photo_id = photo_data.get("id")
            if photo_id:
                uploaded_ids.append(photo_id)
        
        if not uploaded_ids:
            return {
                "success": False,
                "error": "อัปโหลดรูปไม่สำเร็จ"
            }
        
        # 2) สร้างโพสต์หลักที่แนบรูปหลายรูป
        params = {
            "access_token": token,
            "message": message
        }
        
        for idx, pid in enumerate(uploaded_ids):
            params[f"attached_media[{idx}]"] = json.dumps({"media_fbid": pid})
        
        post_resp = requests.post(
            f"{BASE_URL}/me/feed",
            params=params
        )
        post_resp.raise_for_status()
        data = post_resp.json()
        
        return {
            "success": True,
            "data": data,
            "photo_ids": uploaded_ids,
            "post_id": data.get("id"),
            "post_url": f"https://www.facebook.com/{data.get('id')}" if data.get("id") else None
        }
    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if hasattr(e, "response") and e.response is not None:
            try:
                error_data = e.response.json()
                error_msg = error_data.get("error", {}).get("message", str(e))
            except:
                error_msg = e.response.text
        return {
            "success": False,
            "error": error_msg
        }


def delete_post(token: str, post_id: str) -> Dict:
    """ลบโพสต์ของ Page ตาม post_id"""
    try:
        response = requests.delete(
            f"{BASE_URL}/{post_id}",
            params={
                "access_token": token,
            },
        )
        response.raise_for_status()
        data = response.json()
        return {
            "success": True,
            "data": data,
        }
    except requests.exceptions.RequestException as e:
        error_msg = str(e)
        if hasattr(e, "response") and e.response is not None:
            try:
                error_data = e.response.json()
                error_msg = error_data.get("error", {}).get("message", str(e))
            except:
                error_msg = e.response.text
        return {
            "success": False,
            "error": error_msg,
        }

def load_config() -> Dict:
    """โหลดข้อมูล config"""
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {"pages": []}
    except json.JSONDecodeError:
        return {"pages": []}

def save_config(config: Dict):
    """บันทึกข้อมูล config"""
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def load_history() -> Dict:
    """โหลดประวัติการโพสต์"""
    try:
        with open(HISTORY_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {"items": []}
    except json.JSONDecodeError:
        return {"items": []}


def save_history(history: Dict):
    """บันทึกประวัติการโพสต์"""
    with open(HISTORY_PATH, 'w', encoding='utf-8') as f:
        json.dump(history, f, indent=2, ensure_ascii=False)

def add_page(name: str, token: str) -> Dict:
    """เพิ่ม Page ใหม่"""
    config = load_config()
    
    # ทดสอบ Token ก่อน
    test_result = test_token(token)
    if not test_result.get("success"):
        return {
            "success": False,
            "error": test_result.get("error", "Token ไม่ถูกต้อง")
        }
    
    # ดึง Page ID
    page_id = test_result.get("debug", {}).get("data", {}).get("profile_id")
    page_name = test_result.get("page", {}).get("name", name)
    
    # สร้าง ID ใหม่
    new_id = f"page_{uuid.uuid4().hex[:8]}"
    
    # เพิ่ม Page
    new_page = {
        "id": new_id,
        "name": page_name or name,
        "token": token,
        "page_id": page_id,
        "created_at": datetime.now().strftime('%Y-%m-%d'),
        "active": True
    }
    
    config["pages"].append(new_page)
    save_config(config)
    
    return {
        "success": True,
        "page": new_page
    }

def delete_page(page_id: str) -> bool:
    """ลบ Page"""
    config = load_config()
    config["pages"] = [p for p in config["pages"] if p["id"] != page_id]
    save_config(config)
    return True

def update_page(page_id: str, name: Optional[str] = None, token: Optional[str] = None, active: Optional[bool] = None, 
                district: Optional[str] = None, province: Optional[str] = None, areas: Optional[List[str]] = None) -> Dict:
    """อัปเดตข้อมูล Page"""
    config = load_config()
    
    for page in config["pages"]:
        if page["id"] == page_id:
            if name is not None:
                page["name"] = name
            if token is not None:
                # ทดสอบ Token ก่อน
                test_result = test_token(token)
                if not test_result.get("success"):
                    return {
                        "success": False,
                        "error": test_result.get("error", "Token ไม่ถูกต้อง")
                    }
                page["token"] = token
                page["page_id"] = test_result.get("debug", {}).get("data", {}).get("profile_id")
            if active is not None:
                page["active"] = active
            
            # Update SEO Fields
            if district is not None:
                page["district"] = district
            if province is not None:
                page["province"] = province
            if areas is not None:
                page["areas"] = areas
                
            save_config(config)
            return {
                "success": True,
                "page": page
            }
    
    return {
        "success": False,
        "error": "ไม่พบ Page"
    }
